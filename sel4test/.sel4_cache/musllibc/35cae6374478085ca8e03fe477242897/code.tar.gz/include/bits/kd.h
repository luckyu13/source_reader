#include <linux/kd.h>
